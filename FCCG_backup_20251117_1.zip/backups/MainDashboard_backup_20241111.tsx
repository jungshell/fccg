// 이 파일은 2024년 11월 11일 현재 상태의 MainDashboard.tsx 백업입니다.
// 10월 31일 14시 시점으로 되돌리기 전 백업본입니다.
// 복원하려면 이 파일을 frontend/src/pages/MainDashboard.tsx로 복사하세요.

